/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;


import java.awt.Color;
import java.awt.Dimension;
import java.util.Random;
import javax.swing.BoxLayout;
import javax.swing.JPanel;


/**
 *
 * @author zachary
 */
public class Primary extends JPanel{
    


public Primary(){
		setPreferredSize(new Dimension (2000,2000));
		setLayout (new BoxLayout(this, BoxLayout.X_AXIS));
		setBackground (Color.gray);
	    TablePanel table1 = new TablePanel();
	    ChooseNum choose = new ChooseNum();
            PRB01 prb01 = new PRB01();
            PRB03 prb03 = new PRB03();
            PRB04 prb04 = new PRB04();
            LeftPanel left = new LeftPanel(this, table1, choose, prb01, prb03, prb04);
            
            
	   
	    add(left);
	    add(table1);
	    validate();
}
   
    

    //fills the deck with cards	



}

  


    
	





