/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author zachary
 */

public class PRB01 extends JPanel{

    private JPanel imagePanel, buttonPanel; 
    private TablePanel table;
    private JButton stopButton, startButton;
    private JLabel image;
     private final int WIDTH = 300, HEIGHT = 100;
   private final int IMAGE_SIZE = 35;
   private int delay = 60;
   private ImageIcon img, sadimage;
   private Timer timer;
   private int x, y, moveX, moveY, x2, y2, moveX2, moveY2;
   private boolean flag = true;
   private int x1, y1;
    
    private PRB01 p1;
    public PRB01(){
        p1 = this;
        //sets the panel
        setBackground(Color.lightGray); 
        setPreferredSize(new Dimension(900, 600)); 
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); 
        
        //instantiates variable
        //ButtonListener buttonListener = new ButtonListener();
        imagePanel = new JPanel();
        buttonPanel = new JPanel();
        stopButton = new JButton("stop"); 
        startButton = new JButton("start");
        
           timer = new Timer(delay, new ButtonListener());
           
      img = new ImageIcon ("src/prb04/original.png");
      sadimage = new ImageIcon ("src/prb04/YellowCirle.png");
      
      x = 0;
      y = 40;
      moveX = moveY = 3;
      x2 = 250;
      y2 = 40;
      moveX2 = 1;
      moveY2 = 10;
      
     
      
          
        //adds action listeners to the buttons
       stopButton.addActionListener(new PRB01.ButtonListener()); 
       startButton.addActionListener(new PRB01.ButtonListener()); 
        
        //adds image to imagePanel
       
        
        //adds buttons to buttonPanel
        buttonPanel.add(stopButton); 
        buttonPanel.add(startButton); 
       
        p1.add(imagePanel); 
        p1.add(buttonPanel);
        validate();
    }
    
     public void paintComponent (Graphics page)
   {
      super.paintComponent (page);
      img.paintIcon (this, page, x, y);
      sadimage.paintIcon (this, page, x2, y2);
   }

   //*****************************************************************
   //  Represents the action listener for the timer.
   //*****************************************************************
   private class ButtonListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Updates the position of the image and possibly the direction
      //  of movement whenever the timer fires an action event.
      //--------------------------------------------------------------
       
      public void actionPerformed (ActionEvent e)
      {
          if(e.getSource() == startButton){
               timer.start(); 
         x += moveX;
         y += moveY;
         
         x2 += moveX2;
         y2 += moveY2;

       if (x <= 0 || x >= WIDTH-IMAGE_SIZE)
      // if (x <= 0 || x >= WIDTH) 
            moveX = moveX * -1;

       if (y <= 0 || y >= HEIGHT-IMAGE_SIZE)
     //	 if (y <= 0 || y >= HEIGHT)
            moveY = moveY * -1;
       
       if (x2 <= 0 || x2 >= WIDTH-IMAGE_SIZE)
 	      // if (x <= 0 || x >= WIDTH) 
 	    moveX2 = moveX2 * -1;

       if (y2 <= 0 || y2 >= HEIGHT-IMAGE_SIZE)
 	     //	 if (y <= 0 || y >= HEIGHT)
 	    moveY2 = moveY2 * -1;
      
         repaint();
          }
        if(e.getSource() == stopButton){
            timer.stop();
        }
          
      }
   }
   
}
    
    

//private class ButtonListener implements ActionListener {
//        
//        public void actionPerformed(ActionEvent e) { 
//            if(e.getSource() == startButton){
//                
//            }
//            if(e.getSource() == stopButton){
//                
//            }
//        }
//    }


    


    
    






     
