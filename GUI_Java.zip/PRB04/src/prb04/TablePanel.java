/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import javax.swing.JPanel;

/**
 *
 * @author zachary
 */
public class TablePanel extends JPanel {
   
    
}
