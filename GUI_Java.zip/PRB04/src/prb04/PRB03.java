/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.*;
/**
 *
 * @author zachary
 */
public class PRB03 extends JPanel{
private JPanel btnPanel, ImgPanel;
private PRB03 prb03;
private JButton firstImg, secImg, thrdImg, frthImg, fifthImg;

PRB03(){
    //instantiates buttons
     setBackground(Color.lightGray); 
        setPreferredSize(new Dimension(900, 600)); 
        setMinimumSize(new Dimension(900, 600)); 
        setMaximumSize(new Dimension(900, 600)); 
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); 
        setBorder(BorderFactory.createLineBorder (Color.black, 1));
        
    firstImg = new JButton("First Image");
    secImg = new JButton("Second Image");
    thrdImg = new JButton("Third Image");
    frthImg = new JButton("Fourth Image");
    fifthImg = new JButton("Fifth Image");
    //instantiates button and image panel
    btnPanel = new JPanel();
    ImgPanel = new JPanel();
    ImageIcon image = new ImageIcon();
    
    btnPanel.add(firstImg);
    btnPanel.add(secImg);
    btnPanel.add(thrdImg);
    btnPanel.add(frthImg);
    btnPanel.add(fifthImg);
    
    JLabel imagelabel = new JLabel();
    
    firstImg.addActionListener(new PRB03.ButtonListener());
    secImg.addActionListener(new PRB03.ButtonListener());
    thrdImg.addActionListener(new PRB03.ButtonListener());
    frthImg.addActionListener(new PRB03.ButtonListener());
    fifthImg.addActionListener(new PRB03.ButtonListener());
    
    
    //adds images to panel
    
    
    add(btnPanel);
    add(ImgPanel);
}


     private class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == firstImg)
            firstImg.setIcon(new ImageIcon("src/prb04/original.png")); //set to icon in file
            else if (e.getSource() == secImg)
            secImg.setIcon(new ImageIcon("src/prb04/PinkCircle.png"));
            else if (e.getSource() == thrdImg)
            thrdImg.setIcon(new ImageIcon("src/prb04/RedCircle.png"));
            else if (e.getSource() == frthImg)
            frthImg.setIcon(new ImageIcon("src/prb04/YellowCircle.png"));
            else if (e.getSource() == fifthImg)
            fifthImg.setIcon(new ImageIcon("src/prb04/BlueCircle.png"));
 }
}}
