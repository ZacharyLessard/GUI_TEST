/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author zachary
 */
public class ChooseNum extends JPanel{
        private JLabel inputLabel;
	private TablePanel table;
	private Primary primary;
        private JPanel btn = new JPanel();
        private JPanel card = new JPanel();
        private Card[] deck = new Card [52];
        private Card[] backDeck = new Card [5];
        private JButton dealcards= new JButton("deal cards");
        private JButton showcards=new JButton("show cards");
        private ChooseNum cn;
	public ChooseNum()
	{
                cn = this;
                fillDeck();
                shuffle();
		backDeck();
                
		dealcards.addActionListener (new ButtonListener());
                showcards.addActionListener (new ButtonListener());
		
		btn.add(dealcards);
		btn.add(showcards);
                cn.add(btn);
                cn.add(card);
                
                

                
              setPreferredSize (new Dimension(900, 600));
	      setBackground (Color.gray);
	      validate();
	}

	
	      //--------------------------------------------------------------
	      //  Performs the conversion when the enter key is pressed in
	      //  the text field.
	      //--------------------------------------------------------------
	 private class ButtonListener implements ActionListener {
        
        public void actionPerformed(ActionEvent e) { 

            if(e.getSource() == showcards){
                 card.removeAll();
                 Card[] temp = getDeck();
                 btn.add(showcards);
                 btn.add(dealcards);
                 card.repaint();
            
	    	
                for (int x = 0; x < 5; x++)
             {
            	 card.add(temp[x]);
             }
                add(btn);
                add(card);
                validate();
            }
             
            if(e.getSource() == dealcards){
	    	card.removeAll();
                 Card[] temp = cardBack();
                 btn.add(showcards);
                 btn.add(dealcards);
                 card.repaint();
            
	    	
                for (int x = 0; x < 5; x++)
             {
            	 card.add(temp[x]);
             }
                add(btn);
                add(card);
                validate();
        }
        }
      
 private class LineListener implements MouseListener, MouseMotionListener
{
//--------------------------------------------------------------
//  Captures the initial position at which the mouse button is
//  pressed.
//--------------------------------------------------------------
public void mousePressed (MouseEvent event)
{
 
}

//--------------------------------------------------------------
//  Gets the current position of the mouse as it is dragged and
//  redraws the line to create the rubberband effect.
//--------------------------------------------------------------
public void mouseDragged (MouseEvent event)
{
 
}

//--------------------------------------------------------------
//  Provide empty definitions for unused event methods.
//--------------------------------------------------------------
public void mouseClicked (MouseEvent event) {}
public void mouseReleased (MouseEvent event) {}
public void mouseEntered (MouseEvent event) {}
public void mouseExited (MouseEvent event) {}
public void mouseMoved (MouseEvent event) {}
}
         }
        public void backDeck(){
            for(int x =0; x < 5;x++){
            backDeck[x] = new Card(25,25);
            }
                   
        }
  public Card[] cardBack(){
          return backDeck;
         }
        public void fillDeck(){
    int x =0;
    for (int suit = 1; suit< 5; suit++){
        for(int number = 1; number <14; number++){
        deck[x++] = new Card(number, suit);
        }
    }
}
         public Card[] getDeck(){
        return deck;
    }
    public void setDeck(Card[] deck){
        this.deck = deck;
    }
//shuffles the deck
public void shuffle()
{   
	
	Random gen = new Random();
	int y=0;
	Card temp;
	for (int x = 0; x < deck.length; x++ )
	{
		y=gen.nextInt(52);  //if its card deck how big should this number be
		temp = deck[x];
		deck[x]=deck[y];
		deck[y]=temp;
	}	
		
}	
	 }

