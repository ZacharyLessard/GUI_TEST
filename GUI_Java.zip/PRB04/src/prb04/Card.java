/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author zachary
 */
public class Card extends JPanel {
private int number;
private int suit;

	public Card(int number, int suit)
	{
            
		this.number = number;
                this.suit=suit;
		setPreferredSize (new Dimension(120, 150));
                if(suit==25){
                    setBackground (Color.BLACK);
                }
                else{
		setBackground (Color.white);
	}
        }
	public void BackCard(int backsuit){
            
        }
	public int getNumber(){
    return number;
}

public void setNumber(int number){
    this.number=number;
}

public int getSuit(){
    return suit;
}
public void setSuit(int suit){
    this.suit=suit;
}
//creating the shapes on the cards and sets colors for specific cards

	public void paintComponent (Graphics g){
            
		super.paintComponent(g); 
		g.setColor (Color.black); 
                String suitOut= null;
		if (suit==1){
                    suitOut=("hearts");
                     g.setColor(Color.RED);
                }
                if (suit==2){
                    suitOut=("clubs");
                     g.setColor(Color.BLACK);
                }
                if (suit==3){
                    suitOut=("diamonds");
                    g.setColor(Color.RED);
                }
                if (suit==4){
                    suitOut=("spades");
                    g.setColor(Color.BLACK);
                }
		if (suit < 3)
			g.fillOval(0, 0, 20, 20);
                else 
                        g.fillRect(0, 0, 20, 20);
                String numOut=Integer.toString(number);
                
                        g.drawString(numOut + " of " + suitOut,25, 70);
                if (suit < 3)
			g.fillOval(98, 98, 20, 20);
                else if(suit > 2)
                        g.fillRect(98, 98, 20, 20);
                if(number == 25 && suit == 25){
                    g.setColor (Color.BLACK);
                    
                }
			
                
		}}
