/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author zachary
 */
public class PRB04 extends JPanel{
private JPanel circlePanel, buttonPanel; 
private JButton redButton, yellowButton, blueButton, greenButton, rightButton, LeftButton, DownButton, UpButton;
private Color currentColor;
 public PRB04(){
        setBackground(Color.lightGray); 
        setPreferredSize(new Dimension(900, 600)); 
        setMinimumSize(new Dimension(900, 600)); 
        setMaximumSize(new Dimension(900, 600)); 
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); 
        setBorder(BorderFactory.createLineBorder (Color.black, 1));
        circlePanel = new JPanel();
        buttonPanel = new JPanel();
        redButton = new JButton("red circle"); 
        yellowButton = new JButton("yellow circle");
        blueButton = new JButton("blue circle");
        greenButton = new JButton("green circle");
        rightButton = new JButton("right Button"); 
        LeftButton = new JButton("Left Button");
        DownButton = new JButton("down circle");
        UpButton = new JButton("up circle");
        //adds buttons to circle Panel
         buttonPanel.add(redButton);
         buttonPanel.add(yellowButton);
         buttonPanel.add(blueButton);
         buttonPanel.add(greenButton);
         buttonPanel.add(rightButton);
         buttonPanel.add(LeftButton);
         buttonPanel.add(DownButton);
         buttonPanel.add(UpButton);
                
        //adds circle to circle panel
        	redButton.addActionListener (new PRB04.ButtonListener());
                yellowButton.addActionListener (new PRB04.ButtonListener());
                blueButton.addActionListener (new PRB04.ButtonListener());
                greenButton.addActionListener (new PRB04.ButtonListener());
                rightButton.addActionListener (new PRB04.ButtonListener());
                LeftButton.addActionListener (new PRB04.ButtonListener());
                DownButton.addActionListener (new PRB04.ButtonListener());
                UpButton.addActionListener (new PRB04.ButtonListener());
         
         add(circlePanel);
         add(buttonPanel);
          int x = 0;
          int y = 0;
 }
  
  
    private class ButtonListener implements ActionListener {
        
        public void actionPerformed(ActionEvent e) { 
            if(e.getSource() == redButton){
                       currentColor = Color.RED;   
                       repaint();
                       validate();
            }
            if(e.getSource() == yellowButton){
                        currentColor = Color.YELLOW;   
                       repaint();
                       validate();
            }
            if(e.getSource() == blueButton){
                currentColor = Color.BLUE;   
                repaint();
                validate();
            }
            if(e.getSource() == greenButton){
                currentColor = Color.GREEN;   
                repaint();
                validate();
            }
        }
    }
    public void paint(Graphics g) {
       super.paint(g);
       g.setColor(currentColor);
       g.fillOval(100, 100, 100, 100);
    }



    
}
