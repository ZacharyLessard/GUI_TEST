/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prb04;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author zachary
 */

public class LeftPanel extends JPanel{
    private JButton prb1, prb2,prb3, prb4;
    private TablePanel table;
    private Primary panel1;
    private ChooseNum choose;
    private PRB01 p1;
    private PRB03 p3;
    private PRB04 p4;
    public LeftPanel(Primary panel1, TablePanel table, ChooseNum choose, PRB01 p1, PRB03 p3,PRB04 p4){
        setLayout (new BoxLayout(this, BoxLayout.X_AXIS));
        this.panel1 = panel1;
        this.table = table;
        this.choose = choose;
        this.p1 =p1;
        this.p3 = p3;
        this.p4 = p4;
        
        
        //declares the new buttons
        prb1 = new JButton("prb01");
        prb2 = new JButton("prb02");
        prb3 = new JButton("prb03");
        prb4 = new JButton("prb04");
        
        prb1.addActionListener(new ButtonListener());
        prb2.addActionListener(new ButtonListener());
        prb3.addActionListener(new ButtonListener());
        prb4.addActionListener(new ButtonListener());
        add(prb1);
        add(prb2);
        add(prb3);
        add(prb4);
        validate();
    }
    private class ButtonListener implements ActionListener {
        
        public void actionPerformed(ActionEvent e) { 
            if(e.getSource() == prb1){
                table.revalidate();
                table.repaint();
                table.removeAll();
                table.add(p1);
            }
            
            if(e.getSource() == prb2){
                table.revalidate();
                table.repaint();
                table.removeAll();
                table.add(choose);
            }
            if(e.getSource() == prb3){
                table.revalidate();
                table.repaint();
                table.removeAll();
                table.add(p3);
            }
            if(e.getSource() == prb4){
                table.revalidate();
                table.repaint();
                table.removeAll();
                table.add(p4);
            }
        }
        }
}
